# -*- coding: utf-8 -*-

# Import necessary libraries
import pandas as pd
import ai_wonder as wonder

# Input with default values
def user_input(prompt, default):
    response = input(f"{prompt} (default: {default}): ")
    return response if response else default

# The driver
if __name__ == "__main__":
    print(f"Hanoi Fire Changed 'Fire_Scale' Predictor")
    print("Powered by AI Wonder\n")
    
    # User inputs
    DamageScale = user_input("Damage_Scale", "'Large'")
    SprinklerSystemPresent = user_input("Sprinkler_System_Present", "'No'")
    FireSafetyTrainingConducted = user_input("Fire_Safety_Training_Conducted", "'No'")
    ElectricalEquipmentInspectionConducted = user_input("Electrical_Equipment_Inspection_Conducted", "'No'")
    GasEquipmentInspectionConducted = user_input("Gas_Equipment_Inspection_Conducted", "'No'")
    RecentRepairReplacementHistory = user_input("Recent_Repair_Replacement_History", "'1-3 years'")
    Month = int(user_input("Month", 9))
    NumberofFloors = int(user_input("Number_of_Floors", 8))
    NumberofFireExtinguishers = int(user_input("Number_of_Fire_Extinguishers", 7))
    NumberofEmergencyExits = int(user_input("Number_of_Emergency_Exits", 6))
    NumberofFireAlarms = int(user_input("Number_of_Fire_Alarms", 5))

    # Make datapoint from user input
    point = pd.DataFrame([{
        'Damage_Scale': DamageScale,
        'Sprinkler_System_Present': SprinklerSystemPresent,
        'Fire_Safety_Training_Conducted': FireSafetyTrainingConducted,
        'Electrical_Equipment_Inspection_Conducted': ElectricalEquipmentInspectionConducted,
        'Gas_Equipment_Inspection_Conducted': GasEquipmentInspectionConducted,
        'Recent_Repair_Replacement_History': RecentRepairReplacementHistory,
        'Month': Month,
        'Number_of_Floors': NumberofFloors,
        'Number_of_Fire_Extinguishers': NumberofFireExtinguishers,
        'Number_of_Emergency_Exits': NumberofEmergencyExits,
        'Number_of_Fire_Alarms': NumberofFireAlarms,
    }])

    # Predict
    model = wonder.load_model('hanoi_fire_changed_model.pkl')
    prediction = str(model.predict(point)[0])
    print(f"\nPrediction of 'Fire_Scale' is '{prediction}'.")
###
