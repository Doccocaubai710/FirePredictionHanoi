pip3 install -r requirements.txt -q
streamlit run 'hanoi_fire_changed_webapp.py' --server.port 7021
