# -*- coding: utf-8 -*-

# Import necessary libraries
import streamlit as st
import pandas as pd
import pickle
import matplotlib.pyplot as plt
import ai_wonder as wonder

# The driver
if __name__ == "__main__":
    # Streamlit interface
    st.subheader(f"Hanoi Fire Changed 'Fire_Scale' Predictor")
    st.markdown("Powered by :blue[**AI Wonder**]")
    st.markdown("")

    # Arrange radio buttons horizontally
    st.write('<style> div.row-widget.stRadio > div { flex-direction: row; } </style>',
        unsafe_allow_html=True)

    # User inputs
    DamageScale = st.radio("Damage_Scale", ['Medium', 'Small', 'Large'], index=1)
    SprinklerSystemPresent = st.radio("Sprinkler_System_Present", ['Yes', 'No'], index=0)
    FireSafetyTrainingConducted = st.radio("Fire_Safety_Training_Conducted", ['No', 'Yes'], index=0)
    ElectricalEquipmentInspectionConducted = st.radio("Electrical_Equipment_Inspection_Conducted", ['No', 'Yes'], index=0)
    GasEquipmentInspectionConducted = st.radio("Gas_Equipment_Inspection_Conducted", ['No', 'Yes'], index=1)
    RecentRepairReplacementHistory = st.selectbox("Recent_Repair_Replacement_History", ['Over 3 years', '1-3 years', 'None', 'Within 1 year'], index=2)
    Month = st.number_input("Month", value=9)
    NumberofFloors = st.number_input("Number_of_Floors", value=8)
    NumberofFireExtinguishers = st.number_input("Number_of_Fire_Extinguishers", value=7)
    NumberofEmergencyExits = st.number_input("Number_of_Emergency_Exits", value=6)
    NumberofFireAlarms = st.number_input("Number_of_Fire_Alarms", value=5)

    # Make datapoint from user input
    point = pd.DataFrame([{
        'Damage_Scale': DamageScale,
        'Sprinkler_System_Present': SprinklerSystemPresent,
        'Fire_Safety_Training_Conducted': FireSafetyTrainingConducted,
        'Electrical_Equipment_Inspection_Conducted': ElectricalEquipmentInspectionConducted,
        'Gas_Equipment_Inspection_Conducted': GasEquipmentInspectionConducted,
        'Recent_Repair_Replacement_History': RecentRepairReplacementHistory,
        'Month': Month,
        'Number_of_Floors': NumberofFloors,
        'Number_of_Fire_Extinguishers': NumberofFireExtinguishers,
        'Number_of_Emergency_Exits': NumberofEmergencyExits,
        'Number_of_Fire_Alarms': NumberofFireAlarms,
    }])

    st.markdown("")

    # Predict and Explain
    if st.button('Predict'):
        st.markdown("")

        with st.spinner("Loading trained model..."):
            state = wonder.load_state('hanoi_fire_changed_state.pkl')
            model = wonder.input_piped_model(state)

        with st.spinner("Making predictions..."):
            prediction = str(model.predict(point)[0])
            st.success(f"Prediction of **{state.target}** is **{prediction}**.")
            st.markdown("")

        with st.spinner("Making explanations..."):
            st.info("Feature Importances")
            importances = pd.DataFrame(wonder.local_explanations(state, point), columns=["Feature", "Value", "Importance"])
            st.dataframe(importances.round(2))

            st.info("Some Counterfactuals")
            counterfactuals = wonder.whatif_instances(state, point).iloc[:20]
            st.dataframe(counterfactuals.round(2))
